"""Optional PySide6 bridge. Core glyph_ocr does not import Qt."""


def qimage_to_pil(image):
    """Copy QImage into an owned RGBA Pillow image, respecting row padding.

    Call before submitting work to a background thread. Do not pass a QPixmap
    to a worker; convert it to QImage on the GUI thread first.
    """
    from PIL import Image
    from PySide6.QtGui import QImage
    from .engine import MAX_PIXELS

    if not isinstance(image, QImage) or image.isNull():
        raise ValueError("Expected a non-empty QImage")
    if image.width() * image.height() > MAX_PIXELS:
        raise ValueError(f"Image exceeds {MAX_PIXELS} pixel limit")
    # This conversion also removes premultiplication before Pillow composites.
    rgba = image.convertToFormat(QImage.Format.Format_RGBA8888)
    return Image.frombytes("RGBA", (rgba.width(), rgba.height()),
                           bytes(rgba.constBits()), "raw", "RGBA",
                           rgba.bytesPerLine(), 1)
