"""Explicit model installation; recognition never invokes this downloader."""
import hashlib
import os
import tempfile
from pathlib import Path

MODEL_ID = "ppocr4-ja-rapidocr3.7.0"
SPECS = {
    "Det": ("det", "ch_PP-OCRv4_det_infer.onnx", "d2a7720d45a54257208b1e13e36a8479894cb74155a5efe29462512d42f49da9"),
    "Cls": ("cls", "ch_ppocr_mobile_v2.0_cls_infer.onnx", "e47acedf663230f8863ff1ab0e64dd2d82b838fceb5957146dab185a89d6215c"),
    "Rec": ("rec", "japan_PP-OCRv4_rec_infer.onnx", "e1075a67dba758ecfc7ebc78a10ae61c95ac8fb66a9c86fab5541e33f085cb7a"),
}
BASE = "https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.7.0/onnx/PP-OCRv4"


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verify_models(root):
    paths = {}
    for stage, (_, name, expected) in SPECS.items():
        path = Path(root) / name
        if not path.is_file() or digest(path) != expected:
            raise ValueError(f"Model missing or damaged: {name}. Run: glyph-ocr prepare")
        paths[stage] = path.resolve()
    return paths


def download_models(root):
    import requests

    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    for folder, name, expected in SPECS.values():
        target = root / name
        if target.is_file() and digest(target) == expected:
            continue
        fd, temporary = tempfile.mkstemp(prefix=name, suffix=".part", dir=root)
        try:
            with os.fdopen(fd, "wb") as out:
                with requests.get(f"{BASE}/{folder}/{name}", stream=True, timeout=(15, 60)) as response:
                    response.raise_for_status()
                    total = 0
                    for chunk in response.iter_content(1024 * 1024):
                        total += len(chunk)
                        if total > 100 * 1024 * 1024:
                            raise ValueError("Model download exceeds size limit")
                        out.write(chunk)
            if digest(temporary) != expected:
                raise ValueError(f"Model checksum mismatch: {name}")
            os.replace(temporary, target)
        finally:
            Path(temporary).unlink(missing_ok=True)
    return verify_models(root)
