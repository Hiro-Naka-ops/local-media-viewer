import argparse
import json
import sys
from pathlib import Path
from time import perf_counter

from .engine import OcrEngine
from .models import download_models


def main(argv=None):
    start = perf_counter()
    parser = argparse.ArgumentParser(description="Offline Japanese OCR: text and original-image coordinates")
    parser.add_argument("--models", default=str(Path.home() / ".glyph-ocr" / "models"), help="Model folder")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("prepare", help="Explicitly download and verify models (network required)")
    recognize = sub.add_parser("recognize", help="Recognize a local image (offline)")
    recognize.add_argument("image", type=Path)
    recognize.add_argument("--output", type=Path, help="New JSON file; existing files are not overwritten")
    recognize.add_argument("--roi", nargs=4, type=int, metavar=("X", "Y", "W", "H"))
    recognize.add_argument("--repeat", type=int, default=1, help="Repeat with the same model session (1..100)")
    recognize.add_argument("--threads", type=int, default=2)
    args = parser.parse_args(argv)
    try:
        if args.command == "prepare":
            print("Downloading/checking OCR models; no images are sent.", file=sys.stderr)
            paths = download_models(args.models)
            print(json.dumps({"status": "ready", "models": {k: str(v) for k, v in paths.items()}}, indent=2))
            return 0
        if not 1 <= args.repeat <= 100:
            raise ValueError("repeat must be 1..100")
        if args.output and args.output.exists():
            raise ValueError("Output already exists. Choose a new file (source files are never overwritten).")
        engine = OcrEngine(args.models, args.threads)
        try:
            engine.prepare()
            runs = []
            for _ in range(args.repeat):
                result = engine.recognize(args.image, tuple(args.roi) if args.roi else None)
                runs.append(result.timings_ms)
            payload = result.to_dict()
            payload["benchmark"] = {"prepare_ms": engine.prepare_ms, "runs_ms": runs,
                                    "command_ms": (perf_counter() - start) * 1000,
                                    "threads": args.threads}
            content = json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False)
            if args.output:
                with args.output.open("x", encoding="utf-8") as stream:
                    stream.write(content + "\n")
            else:
                if hasattr(sys.stdout, "reconfigure"):
                    sys.stdout.reconfigure(encoding="utf-8")
                print(content)
        finally:
            engine.close()
        return 0
    except Exception as exc:
        print(f"OCR error: {exc}", file=sys.stderr)
        return 1
