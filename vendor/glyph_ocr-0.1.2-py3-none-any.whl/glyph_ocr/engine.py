from dataclasses import asdict, dataclass
from pathlib import Path
from threading import Lock
from time import perf_counter

from .models import MODEL_ID, verify_models

MAX_PIXELS = 24_000_000
MAX_BYTES = 100 * 1024 * 1024
# Second reading of lines the recogniser was unsure of. Engraved or embossed
# lettering (highlights, ribbed metal) and noisy small print carry fine detail
# the recogniser mistakes for strokes: "JAPAN" stamped on a key read "JARAN".
# Smoothing the line in proportion to its height removes that detail.
# Only lines below REREAD_BELOW are read again, and the second reading is kept
# only when it is surer by REREAD_GAIN: on clean print the smoothed reading
# scored about the same but dropped a full stop or a first character, so a
# small gain must not win. Tuned on 7 images (see docs/implementation-status.md).
REREAD_BELOW = 0.9
REREAD_GAIN = 0.1
REREAD_BLUR = 0.035


@dataclass(frozen=True)
class TextLine:
    text: str
    quad: tuple
    bbox: tuple
    score: float
    reading_order: int


@dataclass(frozen=True)
class OcrResult:
    image_width: int
    image_height: int
    text: str
    lines: tuple
    status: str
    timings_ms: dict
    warnings: tuple = ()
    coordinate_space: str = "oriented_source_pixels"
    model_id: str = MODEL_ID
    schema_version: str = "0.1"

    def to_dict(self):
        return asdict(self)


def load_image(source):
    from PIL import Image, ImageOps

    def convert(image, apply_exif):
        if image.width * image.height > MAX_PIXELS:
            raise ValueError(f"Image exceeds {MAX_PIXELS} pixel limit")
        if getattr(image, "n_frames", 1) != 1:
            raise ValueError("Animated/multipage images are not supported; select a frame first")
        oriented = ImageOps.exif_transpose(image) if apply_exif else image.copy()
        if "A" in oriented.getbands() or "transparency" in oriented.info:
            rgba = oriented.convert("RGBA")
            background = Image.new("RGBA", rgba.size, "white")
            return Image.alpha_composite(background, rgba).convert("RGB")
        return oriented.convert("RGB")

    if isinstance(source, Image.Image):
        return convert(source, False)
    path = Path(source)
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("Image exceeds 100 MiB file limit")
    with Image.open(path) as image:
        return convert(image, True)


def normalize_lines(output, offset=(0, 0)):
    import math

    texts = getattr(output, "txts", None)
    if texts is None or len(texts) == 0:
        return ()
    boxes, scores = output.boxes, output.scores
    if boxes is None or scores is None or not (len(texts) == len(boxes) == len(scores)):
        raise ValueError("OCR backend returned inconsistent result lengths")
    lines = []
    for text, box, score in zip(texts, boxes, scores):
        quad = tuple((float(p[0]) + offset[0], float(p[1]) + offset[1]) for p in box)
        if len(quad) != 4 or not all(math.isfinite(v) for p in quad for v in p):
            raise ValueError("OCR backend returned invalid geometry")
        if not math.isfinite(float(score)):
            raise ValueError("OCR backend returned invalid score")
        xs, ys = zip(*quad)
        bbox = (min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys))
        lines.append(TextLine(str(text), quad, bbox, float(score), len(lines)))
    return tuple(lines)


def line_crop(bgr, quad):
    """The quad straightened into a rectangle; a column is laid on its side,
    as the backend does before recognising it. None if it has no area."""
    import cv2
    import numpy as np

    points = np.array(quad, dtype=np.float32)
    width = int(round(max(np.linalg.norm(points[0] - points[1]), np.linalg.norm(points[2] - points[3]))))
    height = int(round(max(np.linalg.norm(points[0] - points[3]), np.linalg.norm(points[1] - points[2]))))
    if width < 2 or height < 2:
        return None
    target = np.array([[0, 0], [width, 0], [width, height], [0, height]], dtype=np.float32)
    crop = cv2.warpPerspective(bgr, cv2.getPerspectiveTransform(points, target), (width, height),
                               borderMode=cv2.BORDER_REPLICATE, flags=cv2.INTER_CUBIC)
    if height / width >= 1.5:
        crop = np.rot90(crop)
    return np.ascontiguousarray(crop)


def smoothed(crop):
    import cv2

    return cv2.GaussianBlur(crop, (0, 0), max(0.3, crop.shape[0] * REREAD_BLUR))


def reread_lines(lines, bgr, read_line, offset=(0, 0)):
    """Replace unsure lines by a surer second reading. Returns (lines, count).

    read_line(crop) -> (text, score). Positions are never changed.
    """
    from dataclasses import replace

    result, changed = [], 0
    for line in lines:
        if line.score < REREAD_BELOW:
            quad = [(x - offset[0], y - offset[1]) for x, y in line.quad]
            crop = line_crop(bgr, quad)
            if crop is not None:
                text, score = read_line(smoothed(crop))
                if text.strip() and score >= line.score + REREAD_GAIN:
                    if text != line.text:
                        changed += 1
                    line = replace(line, text=text, score=score)
        result.append(line)
    return tuple(result), changed


class OcrEngine:
    """One persistent CPU engine. Calls are serialized; no implicit downloads."""

    def __init__(self, model_dir="models", threads=2, reread=True):
        if not 1 <= threads <= 64:
            raise ValueError("threads must be between 1 and 64")
        self.model_dir = Path(model_dir)
        self.threads = threads
        # False gives the backend's first reading untouched (for comparison).
        self.reread = reread
        self._backend = None
        self._lock = Lock()
        self.prepare_ms = 0.0

    def prepare(self):
        with self._lock:
            self._prepare()

    def _prepare(self):
        if self._backend is not None:
            return
        start = perf_counter()
        paths = verify_models(self.model_dir)
        from rapidocr import RapidOCR, LangRec, ModelType, OCRVersion

        params = {f"{stage}.model_path": str(path) for stage, path in paths.items()}
        params.update({
            "Rec.lang_type": LangRec.JAPAN,
            "Global.log_level": "error",
            "EngineConfig.onnxruntime.intra_op_num_threads": self.threads,
            "EngineConfig.onnxruntime.inter_op_num_threads": 1,
        })
        for stage in paths:
            params[f"{stage}.ocr_version"] = OCRVersion.PPOCRV4
            params[f"{stage}.model_type"] = ModelType.MOBILE
        # Pinned ONNX hashes include the Japanese character dictionary metadata.
        self._backend = RapidOCR(params=params)
        self.prepare_ms = (perf_counter() - start) * 1000

    def recognize(self, source, region=None):
        with self._lock:
            self._prepare()
            start = perf_counter()
            image = load_image(source)
            width, height = image.size
            offset = (0, 0)
            if region is not None:
                if len(region) != 4 or not all(isinstance(v, int) for v in region):
                    raise ValueError("ROI must contain four integers: x y width height")
                x, y, w, h = region
                if x < 0 or y < 0 or w <= 0 or h <= 0 or x + w > width or y + h > height:
                    raise ValueError("ROI is outside the image")
                image = image.crop((x, y, x + w, y + h))
                offset = (x, y)
            import numpy as np

            bgr = np.asarray(image)[:, :, ::-1].copy()
            loaded = perf_counter()
            # The switches are stated on every call: the backend remembers the
            # last ones it was given, and the re-reading below turns detection off.
            output = self._backend(bgr, use_det=True, use_cls=True, use_rec=True)
            inferred = perf_counter()
            # RapidOCR already undoes its internal resize/padding. Only undo our ROI.
            lines = normalize_lines(output, offset)
            reread = 0
            if self.reread and lines:
                lines, reread = reread_lines(lines, bgr, self._read_line, offset)
            reread_done = perf_counter()
            done = perf_counter()
            warnings = ["Reading order is backend order; vertical/multicolumn layout is not validated."]
            if reread:
                warnings.append(f"{reread} low-confidence line(s) replaced by a second reading of the smoothed line.")
            if max(image.size) > 2000:
                warnings.append("Backend downsizes large input; small text may be lost.")
            return OcrResult(width, height, "\n".join(line.text for line in lines), lines,
                             "ok" if lines else "no_text", {
                                 "load_preprocess": (loaded - start) * 1000,
                                 "inference": (inferred - loaded) * 1000,
                                 "reread": (reread_done - inferred) * 1000,
                                 "postprocess": (done - inferred) * 1000,
                                 "total": (done - start) * 1000,
                             }, tuple(warnings))

    def _read_line(self, crop):
        output = self._backend(crop, use_det=False, use_cls=True, use_rec=True)
        texts = getattr(output, "txts", None)
        if texts is None or len(texts) == 0:
            return "", 0.0
        return str(texts[0]), float(output.scores[0])

    def close(self):
        with self._lock:
            self._backend = None
